to reset use /trigger Reset
to start use /trigger Start
must be 2+ players

:)
